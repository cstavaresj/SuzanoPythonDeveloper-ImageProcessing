from setuptools import setup, find_packages

with open("README.md", "r") as f:
    page_description = f.read()

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="image_processing",
    version="0.0.1",
    author="Carlos Soares",
    author_email="cstavaresj@gmail.com",
    description="Pacote de teste para criação e distribuição",
    long_description=page_description,
    long_description_content_type="text/markdown",
    url="https://github.com/cstavares/SuzanoPythonDeveloper-ImageProcessing",
    packages=find_packages(),
    install_requires=requirements,
    python_requires='>=3.12.1',
)
